#!/usr/bin/env python3

# Created by Gabriel A
# Created on Dec 2020
# This program calculates the average of 3 numbers between 0-100


def main():
    print("We are going to calculate the average of 3 numbers")

    # input
    try:
        into = int(input("Enter a number between 0-100: "))
        intw = int(input("Enter another number: "))
        inth = int(input("Enter a third number: "))
        average = (into + intw + inth) / 3
        print("")

        # process & output
        if into <= 100 and into >= 0:
            if intw <= 100 and intw >= 0:
                if inth <= 100 and inth >= 0:
                    print("The average is {0}.".format(average))
                else:
                    print("One or inputs are negative or above 100.")
            else:
                print("One or inputs are negative or above 100.")
        else:
            print("One or inputs are negative or above 100.")

    except ValueError:
        print("")
        print("One or more inputs are not valid. You entered letters.")


if __name__ == "__main__":
    main()
